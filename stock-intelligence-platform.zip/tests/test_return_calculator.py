from src.bootstrap import Bootstrap


from src.analytics.core.return_calculator import ReturnCalculator


bootstrap = Bootstrap()

explorer = bootstrap.stock_explorer_service

stock = explorer.get_stock("RELIANCE")

calculator = ReturnCalculator(stock.series)

print()

print("Records :", len(series))

print("Daily Return :", calculator.daily_return())

print("Total Return :", calculator.total_return())

print("CAGR :", calculator.cagr())