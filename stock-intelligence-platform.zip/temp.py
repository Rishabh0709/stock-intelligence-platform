from sqlalchemy import create_engine

from src.database.tables import metadata


class DatabaseManager:

    def __init__(self):

        self.engine = create_engine(
            DATABASE_URL,
            future=True,
        )

        metadata.create_all(self.engine)